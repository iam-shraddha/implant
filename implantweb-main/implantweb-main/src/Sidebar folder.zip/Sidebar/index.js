import React, { useState } from 'react';
import { Box, Drawer, List } from '@mui/material';
import { styled } from '@mui/material/styles';
import SidebarHeader from './SidebarHeader';
import SidebarFooter from './SidebarFooter';
import NavItem from './NavItem';
import { navItems } from './config';

const DRAWER_WIDTH = 180;

const DrawerWrapper = styled(Box)(({ theme, isopen }) => ({
  position: 'fixed', // Set position to fixed
  top: 0, // Set top to 0
  left: 0, // Set left to 0
  zIndex: 1300, // Set zIndex to a higher value
  '& .MuiDrawer-paper': {
    position: 'relative',
    whiteSpace: 'nowrap',
    width: DRAWER_WIDTH,
    transition: theme.transitions.create('width', {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen,
    }),
    boxSizing: 'border-box',
    ...(!isopen && {
      overflowX: 'hidden',
      transition: theme.transitions.create('width', {
        easing: theme.transitions.easing.sharp,
        duration: theme.transitions.duration.leavingScreen,
      }),
      width: theme.spacing(7),
      [theme.breakpoints.up('sm')]: {
        width: theme.spacing(9),
      },
    }),
  },
}));

const Sidebar = () => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleDrawer = () => {
    setIsOpen(!isOpen);
  };

  return (
    <DrawerWrapper isopen={isOpen ? 1 : 0}>
      <Drawer
        variant="permanent"
        open={isOpen}
        sx={{
          height: '100vh',
        }}
      >
        <SidebarHeader isOpen={isOpen} onToggle={toggleDrawer} />
        <List sx={{ flex: 1, pt: 1 }}>
          {navItems.map((item) => (
            <NavItem key={item.text} item={item} isOpen={isOpen} />
          ))}
        </List>
        <SidebarFooter isOpen={isOpen} />
      </Drawer>
    </DrawerWrapper>
  );
};

export default Sidebar;