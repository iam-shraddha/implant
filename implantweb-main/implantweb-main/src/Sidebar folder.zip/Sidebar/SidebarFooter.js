import React from 'react';
import { Box, Typography, Avatar } from '@mui/material';
import AdminPanelSettingsIcon from '@mui/icons-material/AdminPanelSettings';

const SidebarFooter = ({ isOpen }) => {
  if (!isOpen) return null;

  return (
    <Box
      sx={{
        position: 'absolute',
        bottom: 0,
        width: '100%',
        borderTop: '1px solid',
        borderColor: 'divider',
        p: 2,
        display: 'flex',
        alignItems: 'center',
        gap: 2,
      }}
    >
      <Avatar sx={{ bgcolor: 'primary.light' }}>
        <AdminPanelSettingsIcon />
      </Avatar>
      <Box>
        <Typography variant="subtitle2" color="text.primary">
          Admin Portal
        </Typography>
        <Typography variant="caption" color="text.secondary">
          v1.0.0
        </Typography>
      </Box>
    </Box>
  );
};

export default SidebarFooter;