// Config.js or wherever BASE_URL is defined
//const BASE_URL = 
//  process.env.NODE_ENV === 'production' 
//    ? ''  // Proxy in production
//    : 'http://ec2-13-235-8-185.ap-south-1.compute.amazonaws.com:8080';  // Direct URL in development
const BASE_URL = 'https://implant.hyperminds.tech';

//http://implant.hyperminds.tech/

export default BASE_URL;
