import React from 'react'
import DashboardContent from '../Components/DashboardContent'
import Sidebar from '../Sidebar'
import Footer from './Footer'

function DashboardPage() {
  return (
    <>
      <Sidebar />
      <DashboardContent />
      <Footer />
    </>
  )
}

export default DashboardPage